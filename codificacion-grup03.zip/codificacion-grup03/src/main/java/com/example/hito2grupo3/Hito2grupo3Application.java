package com.example.hito2grupo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@ConfigurationPropertiesScan
@SpringBootApplication
public class Hito2grupo3Application {

	public static void main(String[] args) {
		SpringApplication.run(Hito2grupo3Application.class, args);
	}

}
